
import CardDetail from '../Card/CardDetail'
import { CartProvider} from '../Context/Cart'

const ContactUs = () => {
  return ( 
    <> 
    <CartProvider>
    <div className='m-0 p-0 w-full mt-20'>

      <CardDetail /> 
      <CardDetail />
      <CardDetail />
      <CardDetail />
    </div>  
    </CartProvider>
    </>
  )
}

export default ContactUs