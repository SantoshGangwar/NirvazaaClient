// import Card from "../Card/Card"
import CategoryCard from "../Card/CategoryCard"
import CategogyCard1 from '../Card/CategogyCard1'
import Nav from  '../Card/Nav'
import Team from '../../Components/Team'
import QuickViews from '../Card/QuickViews'
const Home = () => {
  return ( 
    <>
    {/* <div className="flex justify-evenly  mt-28 ">
  <Card />
  <Card />
  <Card />
  <Card /> 
  
    </div> */}
  <div className=" md:flex "> 
    <CategoryCard /> 
   
  </div> 
  <div>

    <CategogyCard1/>
    <Nav/> 
    <Team/>
    <QuickViews/>
  </div>
    </>
  )
}

export default Home