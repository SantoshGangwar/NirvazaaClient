

// const Footer = () => {
//   return (
  
// <div className="flex items-end w-full min-h-screen bg-white">

//     <footer className="w-full text-gray-700 bg-gray-100 body-font">
//         <div
//             className="container flex flex-col flex-wrap px-5 py-24 mx-auto md:items-center lg:items-start md:flex-row md:flex-no-wrap">
//             <div className="flex-shrink-0 w-64 mx-auto text-center md:mx-0 md:text-left">
//                 <a className="flex items-center justify-center font-medium text-gray-900 title-font md:justify-start">
//                     <svg className="w-auto h-5 text-gray-900 fill-current" viewBox="0 0 202 69"
//                         xmlns="http://www.w3.org/2000/svg">
//                         <path
//                             d="M57.44.672s6.656 1.872 6.656 5.72c0 0-1.56 2.6-3.744 6.552 8.424 1.248 16.744 1.248 23.816-1.976-1.352 7.904-12.688 8.008-26.208 6.136-7.696 13.624-19.656 36.192-19.656 42.848 0 .416.208.624.52.624 4.576 0 17.888-14.352 21.112-18.824 1.144-1.456 4.264.728 3.12 2.392C56.608 53.088 42.152 69 36.432 69c-4.472 0-8.216-5.928-8.216-10.4 0-6.552 11.752-28.08 20.28-42.952-9.984-1.664-20.176-3.64-27.976-3.848-13.936 0-16.64 3.536-17.576 6.032-.104.312-.52.52-.832.312-3.744-7.072-1.456-14.56 14.144-14.56 9.36 0 22.048 4.576 34.944 7.592C54.736 5.04 57.44.672 57.44.672zm46.124 41.08c1.144-1.456 4.264.728 3.016 2.392C100.236 53.088 85.78 69 80.06 69c-4.576 0-8.32-5.928-8.32-10.4v-.208C67.58 64.32 63.524 69 61.34 69c-4.472 0-8.944-4.992-8.944-11.856 0-10.608 15.704-33.072 24.96-33.072 4.992 0 7.384 2.392 8.528 4.576l2.6-4.576s6.656 1.976 6.656 5.824c0 0-13.312 24.336-13.312 30.056 0 .208 0 .624.52.624 4.472 0 17.888-14.352 21.216-18.824zm-40.56 18.72c2.184 0 11.752-13.312 17.368-22.048l4.16-7.488c-8.008-7.904-27.248 29.536-21.528 29.536zm57.564-38.168c-2.184 0-4.992-2.808-4.992-4.784 0-2.912 5.824-14.872 7.28-14.872 2.6 0 6.136 2.808 6.136 6.344 0 2.08-7.176 12.064-8.424 13.312zm-17.68 46.592c-4.472 0-8.216-5.928-8.216-10.4 0-6.656 16.744-34.528 16.744-34.528s6.552 1.976 6.552 5.824c0 0-13.312 24.336-13.312 30.056 0 .208.104.624.624.624 4.472 0 17.888-14.352 21.112-18.824 1.144-1.456 4.264.728 3.12 2.392-6.448 8.944-20.904 24.856-26.624 24.856zM147.244.672s6.656 1.872 6.656 5.72c0 0-25.792 43.784-25.792 53.56 0 .416.208.624.52.624 4.576 0 17.888-14.352 21.112-18.824 1.144-1.456 4.264.728 3.12 2.392C146.412 53.088 131.956 69 126.236 69c-4.472 0-8.216-5.928-8.216-10.4 0-10.4 29.224-57.928 29.224-57.928zM169.7 60.16c3.848-2.392 7.904-6.864 10.816-10.92 6.656-9.464 11.544-20.696 10.504-27.352-.312-3.432-.104-4.056 3.12-2.704 5.2 2.392 11.336 8.632 2.184 22.88-5.2 8.008-12.48 15.288-19.344 19.76-2.704 1.768-6.344 3.328-9.984 4.16-.52.416-1.04.728-1.456.936-1.872 1.352-4.264 2.08-7.592 2.08-14.664 0-16.848-12.272-16.848-16.016 0-2.392 3.224-4.68 4.784-3.744.208.104.312.416.312.624 0 2.808 1.872 13.104 9.984 13.104 7.904 0 3.432-18.304 2.288-27.144-1.456 2.288-3.432 4.992-5.616 8.32-2.6 3.744-5.72 1.456-4.784 0 5.824-8.424 9.152-13.832 11.856-18.616 1.248-2.08 3.328-3.328 6.448-3.328 2.704 0 5.824 3.016 6.864 4.784.312.52 0 1.04-.52 1.144a5.44 5.44 0 00-4.368 5.408c0 6.968 2.6 17.16 1.664 24.856l-.312 1.768z"
//                             fillRule="nonzero" /></svg>
//                 </a>
//                 <p className="mt-2 text-sm text-gray-500">Design, Code and Ship!</p>
//                 <div className="mt-4">
//                     <span className="inline-flex justify-center mt-2 sm:ml-auto sm:mt-0 sm:justify-start">
//                         <a className="text-gray-500 cursor-pointer hover:text-gray-700">
//                             <svg fill="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"
//                                 className="w-5 h-5" viewBox="0 0 24 24">
//                                 <path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"></path>
//                             </svg>
//                         </a>
//                         <a className="ml-3 text-gray-500 cursor-pointer hover:text-gray-700">
//                             <svg fill="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"
//                                 className="w-5 h-5" viewBox="0 0 24 24">
//                                 <path
//                                     d="M23 3a10.9 10.9 0 01-3.14 1.53 4.48 4.48 0 00-7.86 3v1A10.66 10.66 0 013 4s-4 9 5 13a11.64 11.64 0 01-7 2c9 5 20 0 20-11.5a4.5 4.5 0 00-.08-.83A7.72 7.72 0 0023 3z">
//                                 </path>
//                             </svg>
//                         </a>
//                         <a className="ml-3 text-gray-500 cursor-pointer hover:text-gray-700">
//                             <svg fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"
//                                 strokeWidth="2" className="w-5 h-5" viewBox="0 0 24 24">
//                                 <rect width="20" height="20" x="2" y="2" rx="5" ry="5"></rect>
//                                 <path d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37zm1.5-4.87h.01"></path>
//                             </svg>
//                         </a>
//                         <a className="ml-3 text-gray-500 cursor-pointer hover:text-gray-700">
//                             <svg fill="currentColor" stroke="currentColor" strokeLinecap="round"
//                                 strokeLinejoin="round" strokeWidth="0" className="w-5 h-5" viewBox="0 0 24 24">
//                                 <path stroke="none"
//                                     d="M16 8a6 6 0 016 6v7h-4v-7a2 2 0 00-2-2 2 2 0 00-2 2v7h-4v-7a6 6 0 016-6zM2 9h4v12H2z">
//                                 </path>
//                                 <circle cx="4" cy="4" r="2" stroke="none"></circle>
//                             </svg>
//                         </a>
//                     </span>
//                 </div>
//             </div>
//             <div className="flex flex-wrap flex-grow mt-10 -mb-10 text-center md:pl-20 md:mt-0 md:text-left">
//                 <div className="w-full px-4 lg:w-1/4 md:w-1/2">
//                     <h2 className="mb-3 text-sm font-medium tracking-widest text-gray-900 uppercase title-font">About</h2>
//                     <nav className="mb-10 list-none">
//                         <li className="mt-3">
//                             <a className="text-gray-500 cursor-pointer hover:text-gray-900">Company</a>
//                         </li>
//                         <li className="mt-3">
//                             <a className="text-gray-500 cursor-pointer hover:text-gray-900">Careers</a>
//                         </li>
//                         <li className="mt-3">
//                             <a className="text-gray-500 cursor-pointer hover:text-gray-900">Blog</a>
//                         </li>
//                     </nav>
//                 </div>
//                 <div className="w-full px-4 lg:w-1/4 md:w-1/2">
//                     <h2 className="mb-3 text-sm font-medium tracking-widest text-gray-900 uppercase title-font">Support</h2>
//                     <nav className="mb-10 list-none">
//                         <li className="mt-3">
//                             <a className="text-gray-500 cursor-pointer hover:text-gray-900">Contact Support</a>
//                         </li>
//                         <li className="mt-3">
//                             <a className="text-gray-500 cursor-pointer hover:text-gray-900">Help Resources</a>
//                         </li>
//                         <li className="mt-3">
//                             <a className="text-gray-500 cursor-pointer hover:text-gray-900">Release Updates</a>
//                         </li>
//                     </nav>
//                 </div>
//                 <div className="w-full px-4 lg:w-1/4 md:w-1/2">
//                     <h2 className="mb-3 text-sm font-medium tracking-widest text-gray-900 uppercase title-font">Platform
//                     </h2>
//                     <nav className="mb-10 list-none">
//                         <li className="mt-3">
//                             <a className="text-gray-500 cursor-pointer hover:text-gray-900">Terms &amp; Privacy</a>
//                         </li>
//                         <li className="mt-3">
//                             <a className="text-gray-500 cursor-pointer hover:text-gray-900">Pricing</a>
//                         </li>
//                         <li className="mt-3">
//                             <a className="text-gray-500 cursor-pointer hover:text-gray-900">FAQ</a>
//                         </li>
//                     </nav>
//                 </div>
//                 <div className="w-full px-4 lg:w-1/4 md:w-1/2">
//                     <h2 className="mb-3 text-sm font-medium tracking-widest text-gray-900 uppercase title-font">Contact</h2>
//                     <nav className="mb-10 list-none">
//                         <li className="mt-3">
//                             <a className="text-gray-500 cursor-pointer hover:text-gray-900">Send a Message</a>
//                         </li>
//                         <li className="mt-3">
//                             <a className="text-gray-500 cursor-pointer hover:text-gray-900">Request a Quote</a>
//                         </li>
//                         <li className="mt-3">
//                             <a className="text-gray-500 cursor-pointer hover:text-gray-900">+123-456-7890</a>
//                         </li>
//                     </nav>
//                 </div>
//             </div>
//         </div>
//         <div className="bg-gray-300">
//             <div className="container px-5 py-4 mx-auto">
//                 <p className="text-sm text-gray-700 capitalize xl:text-center">© 2020 All rights reserved </p>
//             </div>
//         </div>
//     </footer>

// </div>
//   )
// }

// export default Footer

const Footer = () => {
    return (
      <div>
        <footer className="text-gray-400 body-font bg-slate-900">
          <div className="container px-5 py-24 mx-auto">
            <div className="flex flex-wrap place-content-center text-center -mb-10 -mx-4">
              <div className="lg:w-1/5 md:w-1/2 w-full px-3 text-center lg:text-start">
                <h2 className="title-font text-gray-100 tracking-widest text-sm mb-3 font-semibold ">
                  Quick Links
                </h2>
                <nav className="list-none mb-10 text-xs cursor-pointer">
                  <li>
                    <a className="text-gray-400 hover:text-gray-200 ">Crafts</a>
                  </li>
                  <li className="mt-1">
                    <a className="text-gray-400 hover:text-gray-200">Home</a>
                  </li>
                  <li className="mt-1">
                    <a className="text-gray-400 hover:text-gray-200">Idols</a>
                  </li>
                  <li className="mt-1">
                    <a className="text-gray-400 hover:text-gray-200">
                      Accessories
                    </a>
                  </li>
                  <li className="mt-1">
                    <a className="text-gray-400 hover:text-gray-200">Apparel</a>
                  </li>
                  <li className="mt-1">
                    <a className="text-gray-400 hover:text-gray-200">
                      Wall Decor
                    </a>
                  </li>
                </nav>
              </div>
              <div className="lg:w-1/5 md:w-1/2 w-full px-4 text-center lg:text-start">
                <h2 className="title-font font-semibold text-gray-100 tracking-widest text-sm mb-3">
                  Browse Products By
                </h2>
                <nav className="list-none mb-10 text-xs cursor-pointer">
                  <li>
                    <a className="text-gray-400 hover:text-gray-200">
                      Recommendatios
                    </a>
                  </li>
                  <li className="mt-1">
                    <a className="text-gray-400 hover:text-gray-200">Get Items</a>
                  </li>
                  <li className="mt-1">
                    <a className="text-gray-400 hover:text-gray-200">
                      New Arrivals
                    </a>
                  </li>
                  <li className="mt-1">
                    <a className="text-gray-400 hover:text-gray-200">
                      Popular Products
                    </a>
                  </li>
                  <li className="mt-1">
                    <a className="text-gray-400 hover:text-gray-200">
                      Best Sellers
                    </a>
                  </li>
                  <li className="mt-1">
                    <a className="text-gray-400 hover:text-gray-200">
                      Most Wishlisted
                    </a>
                  </li>
                </nav>
              </div>
              <div className="lg:w-1/5 md:w-1/2 w-full px-4 text-center lg:text-start">
                <h2 className="title-font font-semibold text-gray-100 tracking-widest text-sm mb-3">
                  Customer Service
                </h2>
                <nav className="list-none mb-10 text-xs cursor-pointer">
                  <li>
                    <a className="text-gray-400 hover:text-gray-200">
                      Track Order
                    </a>
                  </li>
                  <li className="mt-1">
                    <a className="text-gray-400 hover:text-gray-200">
                      Shipping Payments
                    </a>
                  </li>
                  <li className="mt-1">
                    <a className="text-gray-400 hover:text-gray-200">
                      Return & Exchanges
                    </a>
                  </li>
                  <li className="mt-1">
                    <a className="text-gray-400 hover:text-gray-200">
                      Terms of Use
                    </a>
                  </li>
                  <li className="mt-1">
                    <a className="text-gray-400 hover:text-gray-200">
                      Privacy Policy
                    </a>
                  </li>
                  <li className="mt-1">
                    <a className="text-gray-400 hover:text-gray-200">
                      Cookies Policy
                    </a>
                  </li>
                </nav>
              </div>
              <div className="lg:w-1/5 md:w-1/2 w-full px-4 text-center lg:text-start">
                <h2 className="title-font font-semibold text-gray-100 tracking-widest text-sm mb-3">
                  Craft Maestros
                </h2>
                <nav className="list-none mb-10 text-xs cursor-pointer">
                  <li>
                    <a className="text-gray-400 hover:text-gray-200">About Us</a>
                  </li>
                  <li className="mt-1">
                    <a className="text-gray-400 hover:text-gray-200">
                      Meet the Founders
                    </a>
                  </li>
                  <li className="mt-1">
                    <a className="text-gray-400 hover:text-gray-200">
                      Our Maestros
                    </a>
                  </li>
                  <li className="mt-1">
                    <a className="text-gray-400 hover:text-gray-200">
                      Contact Us
                    </a>
                  </li>
                </nav>
              </div>
              <div className="lg:w-1/5 md:w-1/2 w-full px-4 text-center lg:text-start">
                <h2 className="title-font font-semibold text-gray-100 tracking-widest text-sm mb-3">
                  Contact Us
                </h2>
                <nav className="list-none mb-10 text-xs">
                  <li>
                    <a className="text-gray-400 ">
                      Vipul Square, Block B, Sector 43, Gurugram, Haryana - 122009
                    </a>
                  </li>
                  <li className="mt-1">
                    <a className="text-gray-400  ">+91-124 4307447</a>
                  </li>
                  <li className="mt-1">
                    <a className="text-gray-400 ">nirvazaa@gmail.com</a>
                  </li>
                </nav>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-400">
            <div className="container px-5 py-12 md:flex md:justify-evenly mx-auto items-center ">
              <div>
                <span className="inline-flex lg:mr-auto lg:mt-0 mt-6 w-full justify-center md:justify-start md:w-auto">
                  <a className="text-gray-100">
                    <svg
                      fill="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      className="w-5 h-5"
                      viewBox="0 0 24 24"
                    >
                      <path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"></path>
                    </svg>
                  </a>
                  <a className="ml-3 text-gray-100">
                    <svg
                      fill="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      className="w-5 h-5"
                      viewBox="0 0 24 24"
                    >
                      <path d="M23 3a10.9 10.9 0 01-3.14 1.53 4.48 4.48 0 00-7.86 3v1A10.66 10.66 0 013 4s-4 9 5 13a11.64 11.64 0 01-7 2c9 5 20 0 20-11.5a4.5 4.5 0 00-.08-.83A7.72 7.72 0 0023 3z"></path>
                    </svg>
                  </a>
                  <a className="ml-3 text-gray-100">
                    <svg
                      fill="none"
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      className="w-5 h-5"
                      viewBox="0 0 24 24"
                    >
                      <rect
                        width="20"
                        height="20"
                        x="2"
                        y="2"
                        rx="5"
                        ry="5"
                      ></rect>
                      <path d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37zm1.5-4.87h.01"></path>
                    </svg>
                  </a>
                  <a className="ml-3 text-gray-100">
                    <svg
                      fill="currentColor"
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="0"
                      className="w-5 h-5"
                      viewBox="0 0 24 24"
                    >
                      <path
                        stroke="none"
                        d="M16 8a6 6 0 016 6v7h-4v-7a2 2 0 00-2-2 2 2 0 00-2 2v7h-4v-7a6 6 0 016-6zM2 9h4v12H2z"
                      ></path>
                      <circle cx="4" cy="4" r="2" stroke="none"></circle>
                    </svg>
                  </a>
                </span>
              </div>
              <div className="text-center mt-2">
                <p className="text-gray-400 text-sm ">
                  © 2023 Nirvazaa —
                  <a
                    href="https://twitter.com/knyttneve"
                    className="text-gray-400 ml-1"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    All Rights Reserved.
                  </a>
                </p>
              </div>
              <div className="flex place-content-center mt-4">
                <img
                  className="h-7 w-10 mx-1 bg-slate-200 "
                  src="/src/assets/img/paypal-3.svg"
                  alt=""
                />
                <img
                  className="h-7 w-10 mx-1 bg-slate-200 object-cover"
                  src="/src/assets/img/mastercard-6.svg"
                  alt=""
                />
                <img
                  className="h-7 w-10 mx-1 bg-slate-200"
                  src="/src/assets/img/paytm-1.svg"
                  alt=""
                />
                <img
                  className="h-7 w-10 mx-1 bg-slate-200 object-cover"
                  src="/src/assets/img/visa.svg"
                  alt=""
                />
              </div>
            </div>
          </div>
        </footer>
      </div>
    );
  };
  
  export default Footer;