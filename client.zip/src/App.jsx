// import  { useState, useEffect } from 'react';
// import axios from 'axios';
// import RegistrationForm from './Components/form.jsx';
// import UserProfile from './Components/profile.jsx'
// import Card from './Components/Card/card.jsx';
// import Navbar from './Components/Navbar.jsx/NavbarPage.jsx';
// import Footer from './Components/Footer/Footer.jsx';
// const UserList = () => {
//   const [users, setUsers] = useState([]);

//   useEffect(() => {
//     // Fetch data from the API endpoint
//     axios.get('http://localhost:3000/api/users')
//       .then(response => {
//         setUsers(response.data);
//       })
//       .catch(error => {
//         console.error('Error fetching data:', error);
//       });
//   }, []); // Empty dependency array ensures useEffect runs once after initial render

//   return ( 
//     <> 
//     <Navbar />
//     <div className='flex  justify-evenly w-full h-auto '>
//     <Card></Card>
//     <Card></Card>
//     <Card></Card>
//     <Card></Card>
//     </div>
//     <div>
//       <h1>User List</h1>
//       <table>
//         <thead>
//           <tr>
//             <th>Username</th>
//             <th>Email</th>
//             <th>Password</th>
//             <th>First Name</th>
//             <th>Last Name</th>
//             <th>Age</th>
//             <th>Gender</th>
//             <th>Street</th>
//             <th>City</th>
//             <th>State</th>
//             <th>Postal Code</th>
//             <th>Country</th>
//             <th>Profile Image URL</th>
//             <th>Profile Image Alt Text</th>
//             <th>Created At</th>
//             <th>Updated At</th>
//             <th>Is Active</th>
//             <th>Roles</th>
//             <th>Theme</th>
//             <th>Notifications</th>
//           </tr>
//         </thead>
//         <tbody>
//         {users.map(user => (
//           <tr key={user._id}>
//             <td>{user.username}</td>
//             <td>{user.email}</td>
//             <td>{user.password}</td>
//             <td>{user.fullName?.firstName}</td>
//             <td>{user.fullName?.lastName}</td>
//             <td>{user.age}</td>
//             <td>{user.gender}</td>
//             <td>{user.address?.street}</td>
//             <td>{user.address?.city}</td>
//             <td>{user.address?.state}</td>
//             <td>{user.address?.postalCode}</td>
//             <td>{user.address?.country}</td>

          
//             <td><img src={`img/${user.profileImage?.url}`} alt={user.profileImage?.altText} /></td>


//             <td>{user.profileImage?.altText}</td>
//             <td>{user.createdAt}</td>
//             <td>{user.updatedAt}</td>
//             <td>{user.isActive?.toString()}</td>
//             <td>{user.roles?.join(', ')}</td>
//             <td>{user.preferences?.theme}</td>
//             <td>{user.preferences?.notifications?.toString()}</td>
//           </tr>
//         ))}
//       </tbody>
//       </table> 
      
//     </div> 
//     <RegistrationForm />

//     <UserProfile></UserProfile>
//    <Footer />
//     </>
//   );
// };

// export default UserList;

import {
  createBrowserRouter,
 
  Route,
  RouterProvider,
  createRoutesFromElements,
} from "react-router-dom"
import Layout from "./Components/Layout"
import Home from "./Components/Pages/Home"
import About from "./Components/Pages/About"
import ContactUs from "./Components/Pages/ContactUs"
import RegistrationForm from './Components/Pages/User'

const router = createBrowserRouter(
createRoutesFromElements(

<Route path="/" element={<Layout/>}>
 
  <Route path="/" element={<Home/>}/>
  <Route path='about' element={<About/>}/>
  <Route path="contact" element={<ContactUs />}/>
  <Route path='register' element={<RegistrationForm/>}/>


</Route>

)

)


const App = () => {
  return (
    <RouterProvider router={router} />
  

    
  )
}

export default App